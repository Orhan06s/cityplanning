// ============================================
// Metropolis — JavaScript (simpel gehouden)
// ============================================

// === Helper: CSRF token uit de meta tag ===
function csrf() {
    return document.querySelector('meta[name="csrf-token"]').content;
}

// === Helper: POST JSON naar een URL en geef de response terug ===
function postJson(url, data) {
    return fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrf()
        },
        body: data ? JSON.stringify(data) : null
    }).then(function(res) { return res.json(); });
}

// === Helper: maak een form en submit het (voor place/remove) ===
function submitForm(action, velden) {
    var form = document.createElement('form');
    form.method = 'POST';
    form.action = action;

    var token = document.createElement('input');
    token.name = '_token';
    token.value = csrf();
    form.appendChild(token);

    Object.keys(velden).forEach(function(naam) {
        var input = document.createElement('input');
        input.name = naam;
        input.value = velden[naam];
        form.appendChild(input);
    });

    document.body.appendChild(form);
    form.submit();
}


// ============================================
// HOOFDPAGINA — grid + library
// ============================================

// Welk library-item is geselecteerd (voor klik-om-te-plaatsen)
var geselecteerdId = null;
var selectedGroupCellId = null;
var selectedGroupId = null;
// Drag state for group moves
var isGroupDragging = false;
var dragStartX = 0;
var dragStartY = 0;
var dragSourceCellId = null;
var dragGroupId = null;
var dragAnchorCellId = null;
var dragAnchorPosition = null;
var dragAnchorRect = null;
var dragSnapTargetEl = null;
var dragGhostElements = [];
var dragGridRect = null;
var cellWidth = 0;
var cellHeight = 0;
var gridGapX = 0;
var gridGapY = 0;
var dragMoved = false;
var dragGroupElements = [];

function saveSelectionState() {
    if (selectedGroupId) {
        sessionStorage.setItem('metropolisSelectedGroupId', selectedGroupId);
        sessionStorage.removeItem('metropolisSelectedCellId');
    } else if (selectedGroupCellId) {
        sessionStorage.setItem('metropolisSelectedCellId', selectedGroupCellId);
        sessionStorage.removeItem('metropolisSelectedGroupId');
    } else {
        sessionStorage.removeItem('metropolisSelectedGroupId');
        sessionStorage.removeItem('metropolisSelectedCellId');
    }
}

function restoreSelectionState() {
    var groupId = sessionStorage.getItem('metropolisSelectedGroupId');
    if (groupId) {
        var cel = document.querySelector('.cel[data-linked-group="' + groupId + '"]');
        if (cel) {
            selectGroupCell(cel);
        }
        sessionStorage.removeItem('metropolisSelectedGroupId');
        return;
    }

    var cellId = sessionStorage.getItem('metropolisSelectedCellId');
    if (cellId) {
        var cel = document.querySelector('.cel[data-cell-id="' + cellId + '"]');
        if (cel && cel.classList.contains('bezet')) {
            selectGroupCell(cel);
        }
        sessionStorage.removeItem('metropolisSelectedCellId');
    }
}

function resetGroupSelection() {
    selectedGroupCellId = null;
    selectedGroupId = null;
    document.querySelectorAll('.cel.group-selected').forEach(function(cel) {
        cel.classList.remove('group-selected');
    });
}

function selectGroupCell(cel) {
    resetGroupSelection();
    selectedGroupCellId = cel.dataset.cellId;
    selectedGroupId = cel.dataset.linkedGroup || null;

    if (selectedGroupId) {
        document.querySelectorAll('.cel[data-linked-group="' + selectedGroupId + '"]').forEach(function(other) {
            other.classList.add('group-selected');
        });
    } else {
        cel.classList.add('group-selected');
    }
}

// Library items: kunnen gesleept worden EN aangeklikt voor selectie
document.querySelectorAll('.library-item').forEach(function(item) {
    item.addEventListener('dragstart', function(e) {
        e.dataTransfer.setData('text/plain', item.dataset.id);
    });

    item.addEventListener('click', function() {
        resetGroupSelection();
        var wasSelected = item.classList.contains('geselecteerd');
        document.querySelectorAll('.library-item.geselecteerd').forEach(function(i) {
            i.classList.remove('geselecteerd');
        });
        if (!wasSelected) {
            item.classList.add('geselecteerd');
            geselecteerdId = item.dataset.id;
        } else {
            geselecteerdId = null;
        }
    });
});

// Grid cellen: kunnen drop ontvangen of geklikt worden (als er iets geselecteerd is)
document.querySelectorAll('.cel').forEach(function(cel) {
    cel.addEventListener('dragover', function(e) { e.preventDefault(); });

    cel.addEventListener('drop', function(e) {
        e.preventDefault();
        var id = e.dataTransfer.getData('text/plain');
        if (id) {
            resetGroupSelection();
            submitForm('/place', { cell_id: cel.dataset.cellId, destination_id: id });
        }
    });

    cel.addEventListener('click', function() {
        if (dragMoved) { dragMoved = false; return; }
        if (geselecteerdId && cel.classList.contains('leeg')) {
            resetGroupSelection();
            submitForm('/place', { cell_id: cel.dataset.cellId, destination_id: geselecteerdId });
            return;
        }

        if (cel.classList.contains('bezet')) {
            if (!selectedGroupCellId) {
                selectGroupCell(cel);
                return;
            }

            if (selectedGroupCellId === cel.dataset.cellId) {
                resetGroupSelection();
                return;
            }

            postJson('/group/link', {
                source_cell_id: selectedGroupCellId,
                target_cell_id: cel.dataset.cellId
            }).then(function(data) {
                if (data.success) {
                    saveSelectionState();
                    location.reload();
                } else {
                    alert(data.message || 'Fout bij koppelen.');
                }
            });
            return;
        }

        if (cel.classList.contains('leeg') && selectedGroupCellId) {
            postJson('/group/move', {
                source_cell_id: selectedGroupCellId,
                target_cell_id: cel.dataset.cellId
            }).then(function(data) {
                if (data.success) {
                    saveSelectionState();
                    location.reload();
                } else {
                    alert(data.message || 'Fout bij verplaatsen.');
                }
            });
        }
    });

    cel.addEventListener('contextmenu', function(e) {
        if (!selectedGroupCellId) {
            return;
        }

        if (selectedGroupCellId === cel.dataset.cellId) {
            return;
        }

        if (!cel.classList.contains('bezet')) {
            return;
        }

        e.preventDefault();

        postJson('/group/link', {
            source_cell_id: selectedGroupCellId,
            target_cell_id: cel.dataset.cellId
        }).then(function(data) {
            if (data.success) {
                saveSelectionState();
                location.reload();
            } else {
                alert(data.message || 'Fout bij koppelen.');
            }
        });
    });

    // --- Drag to move a linked group ---
    cel.addEventListener('mousedown', function(e) {
        if (e.button !== 0) return; // only left button
        if (e.target.closest('.verwijder-btn')) return; // do not start group drag when clicking the remove button
        var linked = cel.dataset.linkedGroup;
        if (!linked) return;

        dragSourceCellId = cel.dataset.cellId;
        dragGroupId = linked;
        dragMoved = false;
        dragGridRect = document.querySelector('.grid').getBoundingClientRect();

        var groupCells = Array.from(document.querySelectorAll('.cel[data-linked-group="' + linked + '"]'));
        var anchorCell = groupCells.reduce(function(min, el) {
            return parseInt(el.dataset.position, 10) < parseInt(min.dataset.position, 10) ? el : min;
        }, groupCells[0]);

        dragAnchorCellId = anchorCell.dataset.cellId;
        dragAnchorPosition = parseInt(anchorCell.dataset.position, 10);
        dragAnchorRect = anchorCell.getBoundingClientRect();
        cellWidth = anchorCell.offsetWidth;
        cellHeight = anchorCell.offsetHeight;
        gridGapX = 10;
        gridGapY = 10;

        var nextInRow = document.querySelector('.cel[data-position="' + (dragAnchorPosition + 1) + '"]');
        if (nextInRow) {
            var nextRowRect = nextInRow.getBoundingClientRect();
            gridGapX = Math.round(nextRowRect.left - (dragAnchorRect.left + cellWidth));
        }
        var below = document.querySelector('.cel[data-position="' + (dragAnchorPosition + 4) + '"]');
        if (below) {
            var belowRect = below.getBoundingClientRect();
            gridGapY = Math.round(belowRect.top - (dragAnchorRect.top + cellHeight));
        }

        dragGhostElements = groupCells.map(function(el) {
            var rect = el.getBoundingClientRect();
            var ghost = el.cloneNode(true);
            ghost.classList.add('drag-ghost');
            ghost.style.position = 'absolute';
            ghost.style.left = rect.left + 'px';
            ghost.style.top = rect.top + 'px';
            ghost.style.width = rect.width + 'px';
            ghost.style.height = rect.height + 'px';
            ghost.style.margin = '0';
            ghost.style.transform = 'none';
            ghost.style.transition = 'transform 0s';
            ghost.style.pointerEvents = 'none';
            ghost.style.opacity = '0.45';
            ghost.style.zIndex = '100';
            document.body.appendChild(ghost);
            return ghost;
        });

        dragGroupElements = groupCells;
        dragGroupElements.forEach(function(el) {
            el.classList.add('dragging');
            el.style.transition = 'transform 0s';
            el.style.zIndex = 60;
            el.style.pointerEvents = 'none';
        });

        dragStartX = e.clientX;
        dragStartY = e.clientY;

        function resetDragVisuals() {
            dragGroupElements.forEach(function(el) {
                el.style.transform = '';
                el.style.transition = '';
                el.classList.remove('dragging');
                el.style.zIndex = '';
                el.style.pointerEvents = '';
            });
            dragGroupElements = [];
            dragGhostElements.forEach(function(el) {
                el.remove();
            });
            dragGhostElements = [];
            if (dragSnapTargetEl) {
                dragSnapTargetEl.classList.remove('drag-over');
                dragSnapTargetEl = null;
            }
        }

        function onMouseMove(ev) {
            var dx = ev.clientX - dragStartX;
            var dy = ev.clientY - dragStartY;
            if (!isGroupDragging && Math.hypot(dx, dy) > 6) {
                isGroupDragging = true;
            }

            if (isGroupDragging) {
                dragGhostElements.forEach(function(ghost) {
                    ghost.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
                });
                dragMoved = true;

                // Determine target cell by picking the element under the anchor ghost center.
                var anchorLeft = dragAnchorRect.left + dx;
                var anchorTop = dragAnchorRect.top + dy;
                var centerX = anchorLeft + (cellWidth / 2);
                var centerY = anchorTop + (cellHeight / 2);

                if (dragSnapTargetEl) {
                    dragSnapTargetEl.classList.remove('drag-over');
                    dragSnapTargetEl = null;
                }

                var elemAt = document.elementFromPoint(Math.round(centerX), Math.round(centerY));
                var snapEl = elemAt ? elemAt.closest('.cel') : null;
                if (snapEl && snapEl.classList.contains('leeg')) {
                    dragSnapTargetEl = snapEl;
                    dragSnapTargetEl.classList.add('drag-over');
                }
            }
        }

        function onMouseUp(ev) {
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);

            if (!isGroupDragging) {
                dragSourceCellId = null;
                dragGroupId = null;
                resetDragVisuals();
                return;
            }

            var dx = ev.clientX - dragStartX;
            var dy = ev.clientY - dragStartY;

            if (dragSnapTargetEl) {
                postJson('/group/move', {
                    source_cell_id: dragAnchorCellId,
                    target_cell_id: dragSnapTargetEl.dataset.cellId
                }).then(function(data) {
                    if (data.success) {
                        saveSelectionState();
                        location.reload();
                    } else {
                        alert(data.message || 'Fout bij verplaatsen.');
                        resetDragVisuals();
                    }
                }).catch(function() {
                    resetDragVisuals();
                });
            } else {
                resetDragVisuals();
            }

            isGroupDragging = false;
            dragSourceCellId = null;
            dragGroupId = null;
            dragAnchorCellId = null;
            dragAnchorPosition = null;
            dragAnchorRect = null;
            dragGridRect = null;
            cellWidth = 0;
            cellHeight = 0;
            gridGapX = 0;
            gridGapY = 0;
        }

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    });

});

document.querySelectorAll('.verwijder-btn').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
        e.stopPropagation();
    });
});

restoreSelectionState();

var grid = document.querySelector('.grid');
if (grid) {
    grid.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    });
}

// Zoekveld in functiebibliotheek
var zoekInput = document.getElementById('zoekterm');
if (zoekInput) {
    zoekInput.addEventListener('input', function() {
        var term = zoekInput.value.toLowerCase();
        document.querySelectorAll('.library-item').forEach(function(item) {
            var naam = item.dataset.name.toLowerCase();
            item.style.display = naam.indexOf(term) !== -1 ? '' : 'none';
        });
    });
}

// Clear Grid button (verwijdert alle functies van het grid)
var clearGridBtn = document.getElementById('clear-grid-btn');
if (clearGridBtn) {
    clearGridBtn.addEventListener('click', function() {
        if (!confirm('Weet je zeker dat je alle functies van het grid wilt verwijderen?')) return;
        postJson('/grid/clear', null).then(function(data) {
            if (data.success) location.reload();
            else alert('Fout bij legen van grid.');
        }).catch(function() { alert('Fout bij legen van grid.'); });
    });
}


// ============================================
// HOVER TOOLTIP op bezette grid-cellen (SIM.10)
// ============================================

var effectsMatrix = window.metroEffectsMatrix;

document.querySelectorAll('.cel.bezet').forEach(function(cel) {
    cel.addEventListener('mouseenter', function() { toonTooltip(cel); });
    cel.addEventListener('mouseleave', verwijderTooltips);
});

function toonTooltip(cel) {
    if (!effectsMatrix) return;
    var fn = cel.dataset.functionName;
    if (!effectsMatrix[fn]) return;

    verwijderTooltips();

    var tt = document.createElement('div');
    tt.className = 'cel-tooltip';

    Object.keys(effectsMatrix[fn]).forEach(function(cat) {
        var v = effectsMatrix[fn][cat];
        var teken = v > 0 ? '+' + v : String(v);
        var kleur = v > 0 ? 'positief' : (v < 0 ? 'negatief' : 'neutraal');

        var rij = document.createElement('div');
        rij.className = 'tooltip-rij';
        rij.innerHTML =
            '<span>' + cat + '</span>' +
            '<span class="tooltip-waarde is-' + kleur + '">' + teken + '</span>';
        tt.appendChild(rij);
    });

    cel.appendChild(tt);
}

function verwijderTooltips() {
    document.querySelectorAll('.cel-tooltip').forEach(function(t) { t.remove(); });
}


// ============================================
// EFFECTENMATRIX paneel (read-only) — klik om te openen/sluiten
// ============================================

var matrixTrigger = document.getElementById('effecten-trigger');
var matrixPanel   = document.getElementById('effecten-panel');
var matrixSluit   = document.getElementById('effecten-sluit');

if (matrixTrigger && matrixPanel) {
    matrixTrigger.addEventListener('click', function() {
        var wasOpen = !matrixPanel.hidden;
        matrixPanel.hidden = wasOpen;
        matrixTrigger.setAttribute('aria-expanded', String(!wasOpen));
    });

    if (matrixSluit) {
        matrixSluit.addEventListener('click', function() {
            matrixPanel.hidden = true;
            matrixTrigger.setAttribute('aria-expanded', 'false');
        });
    }
}


// ============================================
// EFFECTS MANAGER PAGINA
// ============================================

var tbody = document.getElementById('effects-tbody');

if (tbody) {
    // Wijziging in een input → opslaan via AJAX
    tbody.addEventListener('change', function(e) {
        if (!e.target.classList.contains('effect-input')) return;
        var input = e.target;
        var waarde = parseInt(input.value, 10);

        if (isNaN(waarde) || waarde < -5 || waarde > 5) {
            alert('Waarde moet een getal tussen -5 en 5 zijn.');
            input.value = input.dataset.initial;
            return;
        }

        postJson('/api/effects/update', {
            function_name: input.dataset.function,
            category:      input.dataset.category,
            points:        waarde
        }).then(function(data) {
            if (data.success) {
                input.dataset.initial = waarde;
            } else {
                alert('Fout bij opslaan.');
            }
        });
    });

    // Klik op verwijder-knop in een rij
    tbody.addEventListener('click', function(e) {
        if (!e.target.classList.contains('btn-delete-function')) return;
        var naam = e.target.dataset.function;
        if (!confirm('Weet je zeker dat je "' + naam + '" wilt verwijderen?')) return;

        postJson('/api/effects/delete-function', { function_name: naam })
            .then(function(data) {
                if (data.success) location.reload();
                else alert('Fout bij verwijderen.');
            });
    });

    // Functie toevoegen
    var addBtn = document.getElementById('add-function-btn');
    if (addBtn) {
        addBtn.addEventListener('click', function() {
            var naam = prompt('Voer functienaam in:');
            if (!naam) return;
            naam = naam.trim();
            if (!naam) return;

            postJson('/api/effects/add-function', { function_name: naam })
                .then(function(data) {
                    if (data.success) location.reload();
                    else alert('Fout bij toevoegen. Bestaat deze functie al?');
                });
        });
    }

    // Reset naar standaardwaarden
    var resetBtn = document.getElementById('reset-defaults-btn');
    if (resetBtn) {
        resetBtn.addEventListener('click', function() {
            if (!confirm('Reset alle effecten naar de standaardwaarden? Eigen aanpassingen gaan verloren.')) return;

            postJson('/api/effects/reset-defaults', null)
                .then(function(data) {
                    if (data.success) location.reload();
                    else alert('Fout bij resetten.');
                });
        });
    }

    // Zoekveld in manager
    var zoekManager = document.getElementById('effects-manager-zoek-input');
    if (zoekManager) {
        zoekManager.addEventListener('input', function() {
            var term = zoekManager.value.toLowerCase();
            document.querySelectorAll('.effects-row').forEach(function(row) {
                var fn = row.dataset.function.toLowerCase();
                row.style.display = fn.indexOf(term) !== -1 ? '' : 'none';
            });
        });
    }
}
