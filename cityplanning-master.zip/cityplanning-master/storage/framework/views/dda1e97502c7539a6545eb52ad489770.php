<div class="grid" role="grid" aria-label="<?php echo e(__('Stadsgebied grid')); ?>">
    <?php $COLUMNS = 4; ?>
    <?php $__currentLoopData = $gridCells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $row = intdiv($cell->position, $COLUMNS) + 1;
            $col = ($cell->position % $COLUMNS) + 1;
        ?>
        <div class="cel <?php echo e($cell->destination ? 'bezet' : 'leeg'); ?> <?php echo e($cell->linked_group_id ? 'linked' : ''); ?>"
             role="gridcell"
             tabindex="0"
             data-cell-id="<?php echo e($cell->id); ?>"
             data-position="<?php echo e($cell->position); ?>"
             data-row="<?php echo e($row); ?>"
             data-col="<?php echo e($col); ?>"
             data-linked-group="<?php echo e($cell->linked_group_id ?? ''); ?>"
             <?php if($cell->destination): ?>
                 data-function-name="<?php echo e($cell->destination->name); ?>"
                 data-category="<?php echo e($cell->destination->category); ?>"
             <?php endif; ?>
             aria-label="Cel <?php echo e($cell->position + 1); ?>: <?php echo e($cell->destination ? $cell->destination->getNaam() : __('leeg')); ?>">

            <?php if($cell->destination): ?>
                <span class="cel-icon" aria-hidden="true"><?php echo e($cell->destination->icon); ?></span>
                <span class="cel-naam"><?php echo e($cell->destination->getNaam()); ?></span>

                <?php if($cell->linked_group_id): ?>
                    <span class="cel-link-badge" aria-hidden="true">🔗</span>
                <?php endif; ?>

                <form action="<?php echo e(route('remove')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="cell_id" value="<?php echo e($cell->id); ?>">
                    <button type="submit" class="verwijder-btn"
                            aria-label="<?php echo e(__('Verwijder')); ?> <?php echo e($cell->destination->getNaam()); ?>">✕</button>
                </form>
            <?php else: ?>
                <span class="leeg-tekst" aria-hidden="true"><?php echo e(__('Sleep hier')); ?></span>
            <?php endif; ?>

            <span class="cel-coords" aria-hidden="true"><?php echo e($col); ?>,<?php echo e($row); ?></span>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\Tisam\OneDrive - Avans Hogeschool\Attachments\Leeruitkomst 3\Project\cityplanning-master (3)\cityplanning-master\resources\views/partials/grid.blade.php ENDPATH**/ ?>