<?php $__env->startSection('content'); ?>

<script>
    window.metroEffectsMatrix = <?php echo json_encode($effectsMatrix, 15, 512) ?>;
    window.metroGridCols = 4;
</script>

<?php echo $__env->make('partials.totalen', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container">

    <div class="library">
        <h2><?php echo e(__('Functiebibliotheek')); ?></h2>
        <?php echo $__env->make('partials.library', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('partials.effects', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div class="grid-wrapper">
        <h2><?php echo e(__('Stadsgebied')); ?>

            <button id="clear-grid-btn" class="btn btn-small" style="margin-left:12px"><?php echo e(__('Leeg grid')); ?></button>
        </h2>
        <p class="grid-help">Klik op een geplaatste cel om deze te selecteren. Klik een lege cel om de geselecteerde groep te verplaatsen. Klik met de rechtermuisknop een andere bezette cel om de geselecteerde cel ermee te koppelen.</p>
        <?php echo $__env->make('partials.grid', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Tisam\OneDrive - Avans Hogeschool\Attachments\Leeruitkomst 3\Project\cityplanning-master (3)\cityplanning-master\resources\views/metropolis.blade.php ENDPATH**/ ?>