<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\FunctionEffect;
use App\Models\GridCell;
use App\Services\EffectsCalculator;

class EffectsController extends Controller
{
    public function page()
    {
        EffectsCalculator::ensureSeeded();

        $effects = FunctionEffect::orderBy('function_name')->orderBy('category')->get();
        $groupedByFunction = $effects->groupBy('function_name');

        $calculator = new EffectsCalculator();
        $categories = $calculator->getCategories();

        return view('effecten-beheren', [
            'groupedByFunction' => $groupedByFunction,
            'categories'        => $categories,
        ]);
    }

    public function updateEffect(Request $request)
    {
        $validated = $request->validate([
            'function_name' => 'required|string',
            'category'      => 'required|string',
            'points'        => 'required|integer|between:-5,5',
        ]);

        FunctionEffect::updateOrCreate(
            [
                'function_name' => $validated['function_name'],
                'category'      => $validated['category'],
            ],
            ['points' => $validated['points']]
        );

        return response()->json([
            'success' => true,
            'totals'  => $this->recalculateTotals(),
        ]);
    }

    public function addFunction(Request $request)
    {
        $validated = $request->validate([
            'function_name' => 'required|string|max:50|unique:function_effects,function_name',
        ]);

        $name = trim($validated['function_name']);

        $calculator = new EffectsCalculator();
        $categories = $calculator->getCategories();

        foreach ($categories as $category) {
            FunctionEffect::create([
                'function_name' => $name,
                'category'      => $category,
                'points'        => 0,
            ]);
        }

        session()->flash('success', __('Functie toegevoegd!'));

        return response()->json(['success' => true]);
    }

    public function deleteFunction(Request $request)
    {
        $validated = $request->validate([
            'function_name' => 'required|string',
        ]);

        FunctionEffect::where('function_name', $validated['function_name'])->delete();

        session()->flash('success', __('Functie verwijderd!'));

        return response()->json(['success' => true]);
    }

    /**
     * Nukes function_effects en herbouwt vanuit config/effects.php.
     * Gebruik dit als de data corrupt of helemaal verkeerd staat.
     */
    public function resetToDefaults()
    {
        DB::table('function_effects')->delete();

        $functions = config('effects.functions', []);
        $now = now();
        $rows = [];
        foreach ($functions as $functionName => $effects) {
            foreach ($effects as $category => $points) {
                $rows[] = [
                    'function_name' => $functionName,
                    'category'      => $category,
                    'points'        => $points,
                    'created_at'    => $now,
                    'updated_at'    => $now,
                ];
            }
        }
        DB::table('function_effects')->insert($rows);

        session()->flash('success', __('Effecten gereset naar standaardwaarden!'));

        return response()->json(['success' => true]);
    }

    private function recalculateTotals()
    {
        $gridCells  = GridCell::with('destination')->get();
        $calculator = new EffectsCalculator();
        return $calculator->calculate($gridCells);
    }
}
